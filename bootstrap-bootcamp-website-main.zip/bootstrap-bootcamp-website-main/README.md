# Frontend Bootcamp Website - Bootstrap 5

> Simple one page website for a fake bootcamp

This is part of a [YouTube tutorial](https://www.youtube.com/watch?v=4sosXZsdy-s&t=186s)

### Website Demo
https://www.frontendbootcampdemo.com/
